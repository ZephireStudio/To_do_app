import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';


class Todotile extends StatelessWidget {
  final String TaskName;
  final bool TaskComplete;
  void Function(bool?)? onChanged;
  Function(BuildContext)? deleteFunction;

  Todotile({
    super.key, 
    required this.TaskName, 
    required this.TaskComplete, 
    required this.onChanged,
    required this.deleteFunction,
    });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 10, right: 10, top: 10),
      child: Slidable(
        endActionPane: ActionPane(
          motion: StretchMotion(), 
          children: [
            SlidableAction(
              onPressed: deleteFunction,
              icon: Icons.delete_rounded,
              backgroundColor: Colors.red,
            )
          ],
        ),
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.grey[900],
            borderRadius: BorderRadius.circular(12)
          ),
          child: Row(
            children: [
              // Chkeckbox
              Checkbox(value: TaskComplete, onChanged: onChanged, checkColor: Colors.black, activeColor: Colors.white,),
        
              // Task Name
              Text(TaskName,style: TextStyle(fontSize: 16, decoration: TaskComplete ? TextDecoration.lineThrough : TextDecoration.none, color: Colors.white),)
            ],
          ),
        ),
      ),
    );
  }
}