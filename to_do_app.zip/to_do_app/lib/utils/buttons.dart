import 'package:flutter/material.dart';


class MyButtons extends StatelessWidget {
  final String text;
  VoidCallback onPressed;

  MyButtons({super.key, required this.text, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        width: 85,
        height: 40,
        child: Center(child: Text(text, style: TextStyle(color: Colors.white, fontSize: 18),)),
        decoration: BoxDecoration(
          color: Colors.grey.shade900,
          borderRadius: BorderRadius.circular(12)
        ),
      ),
    );
  }
}