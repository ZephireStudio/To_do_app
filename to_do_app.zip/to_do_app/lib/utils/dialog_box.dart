import 'package:flutter/material.dart';
import 'package:to_do_app/utils/buttons.dart';


class DialogBox extends StatelessWidget {
  final controller;
  VoidCallback onSave;

  DialogBox({super.key, required this.controller, required this.onSave});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.white,
      iconColor: Colors.grey[900],
      content: Container(
        height: 220,
        width: 220,
        
        child: Column(
          children: [
            const SizedBox(height: 30,),
            TextField(
              controller: controller,
              cursorErrorColor: Colors.red,
              cursorColor: Colors.grey[900],
              // Text Decoration
              decoration: InputDecoration(
                hintText: 'Enter Your Task!', 
                border: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey.shade900),
                ), 
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey.shade900),
                ),
                focusColor: Colors.grey[900],
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey.shade900),
                ),
              ),


                // for extra
                style: TextStyle(color: Colors.black),
                ),

                const SizedBox(height: 80,),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Save buttom
                    MyButtons(text: 'Save', onPressed: onSave),

                    const SizedBox(width: 50,),

                    // Cancel buttom
                    MyButtons(text: 'Cancel', onPressed: () => Navigator.pop(context)),
                  ],
                )
          ],
        ),
      )
    );
  }
}