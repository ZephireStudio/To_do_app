import 'package:hive_flutter/hive_flutter.dart';

class TodoDataBase{

  List TodoList = [];

  // reference the box
  final _myBox = Hive.box('mybox');



  void createInitiliase(){

    //

    TodoList = [
      ['Make you To Do app',false],
      ['Do Exercise',false],
    ];
  }

  // load things up or get the data
  void  loaddata(){
    TodoList = _myBox.get('TODOLIST');
  }

  // update the database when change happens in the data
  void updateDatabase(){
    _myBox.put('TODOLIST', TodoList); // .put(key, value) method use to save data in Hive TODOLIST is key (name of the file or folder) and TodoList is value where the data is getting stored
  }

}