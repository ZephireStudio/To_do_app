import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:to_do_app/Database/database.dart';
import 'package:to_do_app/utils/Todotile.dart';
import 'package:to_do_app/utils/dialog_box.dart';

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  // reference the hive box
  final _myBox = Hive.box('mybox');

  final _controller = TextEditingController();

  TodoDataBase DB = TodoDataBase();

  @override
  void initState() {
    // first time opening the app load the default data
    if (_myBox.get("TODOLIST") == null){
      DB.createInitiliase();
    } else {
      // there already exists the data
      DB.loaddata();
    }

    super.initState();
  }

  void Oncheck(int index,bool? value){
    setState(() {
      DB.TodoList[index][1] = !DB.TodoList[index][1];
    });
    DB.updateDatabase();
  }

  void SaveNewTask(){
    List tempList = [_controller.text, false];
    setState(() {
      DB.TodoList.add(tempList);
      _controller.clear();
    });
    Navigator.of(context).pop();
    DB.updateDatabase();
  }


  void createnewTask(){
    showDialog(
      context: context, 
      builder: (context){
        return DialogBox(
          controller: _controller,
          onSave: SaveNewTask,
          // oncancel is already being define in the dialog box as it was pretty short 
        );
      }
    );
    DB.updateDatabase();
  }

  // ignore: capital case error 😅
  void DeleteTask(index){
    setState(() {
      DB.TodoList.removeAt(index);
    });
    DB.updateDatabase();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[600],

      appBar: AppBar(
        title: Text("T O   D O ' S ", style: GoogleFonts.poppins(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 30),),
        backgroundColor: Colors.grey[900],
        centerTitle: true,
      ),

      // floating action buttom
      floatingActionButton: FloatingActionButton(onPressed: createnewTask,child: Icon(Icons.add,color: Colors.white,), backgroundColor: Colors.grey[900],),


      body: Padding(
        padding: EdgeInsets.all(10),
        child: ListView.builder(
          itemCount: DB.TodoList.length,
          itemBuilder: (context, index) {
            return Todotile(
              TaskName: DB.TodoList[index][0], 
              TaskComplete: DB.TodoList[index][1], 
              onChanged: (value) => Oncheck(index,value),
              deleteFunction: (context) => DeleteTask(index),
              );
          }),
        ),
        
    );
  }
}